package com.example.springsecuritydemo01.controller;

import com.example.springsecuritydemo01.domain.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Controller
public class LoginController {
    @Autowired
    AuthenticationManager authenticationManager;

    @PostMapping("/login")
    public String login(@RequestBody User user) {
        // 1. 封装AuthenticationToken对象
        // 2. 通过AuthenticationManager的authenticate方法进行用户认证
        authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(
                    user.getUserName(),
                    user.getPassword()
            )
        );
        // 3. 验证成功后重定向
        return "redirect:/HelloWorld";

    }
}
